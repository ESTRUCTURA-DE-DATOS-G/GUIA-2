package GUI;

import Logica.DiaMayor;
import Logica.LlenarMatriz;
import Logica.PromedioAumento;
import Logica.MayorMenor;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class Inicio extends javax.swing.JFrame {

    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel modeloNuevo = new DefaultTableModel();
    LlenarMatriz matriz = new LlenarMatriz();
    PromedioAumento aumento = new PromedioAumento();
    DiaMayor dia = new DiaMayor();
    FondoPanel fondo = new FondoPanel();

    public Inicio() {

        initComponents();
        this.setTitle("Registro_Buses");
        this.setLocationRelativeTo(null);

        //Inicializa la matriz con el modelo de columnas quemadas
        modelo.addColumn("# Bus");
        modelo.addColumn("Lunes");
        modelo.addColumn("Martes");
        modelo.addColumn("Miercoles");
        modelo.addColumn("Jueves");
        modelo.addColumn("Viernes");
        modelo.addColumn("Sabado");
        modelo.addColumn("Domingo");
        modeloNuevo.addColumn("# Bus");
        modeloNuevo.addColumn("Total");
    }

    public void refrescarTabla(double[][] datosMatriz) {

        //Borra los elementos del modelo
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        for (int i = 0; i < datosMatriz.length; i++) {
            Double[] fila = new Double[datosMatriz[i].length];
            for (int j = 0; j < datosMatriz[i].length; j++) {
                fila[j] = datosMatriz[i][j];
            }
            modelo.addRow(fila);
        }

        jt_Matriz.setModel(modelo);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSpinner1 = new javax.swing.JSpinner();
        jPanel1 = new FondoPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt_Matriz = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_Registro = new javax.swing.JButton();
        btn_masMenos = new javax.swing.JButton();
        btn_mas = new javax.swing.JButton();
        btn_porcentaje = new javax.swing.JButton();
        btn_matrizOriginal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jt_Matriz.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jt_Matriz);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Verdana", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BUSES TRANSCOLOMBIA\n S.A.S");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Logo 1 Resize.jpg"))); // NOI18N

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));

        btn_Registro.setBackground(new java.awt.Color(0, 0, 0));
        btn_Registro.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        btn_Registro.setForeground(new java.awt.Color(255, 255, 255));
        btn_Registro.setText("Registrar Datos");
        btn_Registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_RegistroActionPerformed(evt);
            }
        });

        btn_masMenos.setBackground(new java.awt.Color(0, 0, 0));
        btn_masMenos.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        btn_masMenos.setForeground(new java.awt.Color(255, 255, 255));
        btn_masMenos.setText("Bus con mas y menos ganancia");
        btn_masMenos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_masMenosActionPerformed(evt);
            }
        });

        btn_mas.setBackground(new java.awt.Color(0, 0, 0));
        btn_mas.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        btn_mas.setForeground(new java.awt.Color(255, 255, 255));
        btn_mas.setText("Dia con mas ganancias");
        btn_mas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_masActionPerformed(evt);
            }
        });

        btn_porcentaje.setBackground(new java.awt.Color(0, 0, 0));
        btn_porcentaje.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        btn_porcentaje.setForeground(new java.awt.Color(255, 255, 255));
        btn_porcentaje.setText("Aumento 20%");
        btn_porcentaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_porcentajeActionPerformed(evt);
            }
        });

        btn_matrizOriginal.setBackground(new java.awt.Color(0, 0, 0));
        btn_matrizOriginal.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        btn_matrizOriginal.setForeground(new java.awt.Color(255, 255, 255));
        btn_matrizOriginal.setText("Matriz Base");
        btn_matrizOriginal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_matrizOriginalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_porcentaje, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_mas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_masMenos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Registro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_matrizOriginal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_Registro, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_masMenos, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_mas, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_porcentaje, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_matrizOriginal, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 748, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(141, 141, 141))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_RegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_RegistroActionPerformed

        double[][] nuevosDatos = matriz.Llenar();
        refrescarTabla(nuevosDatos);
    }//GEN-LAST:event_btn_RegistroActionPerformed

    private void btn_masMenosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_masMenosActionPerformed

        double[][] buses = matriz.getBuses();
        MayorMenor masMenor = new MayorMenor();

        //Calcula la suma total de las ventas por cada bus con una instancia
        Map<Integer, Double> sumas = masMenor.calcularSumaTotal(buses);

        //Encuentra el bus que mas gano y el que menos
        int[] mayorMenor = masMenor.encontrarMayorMenor(sumas);

        refrescarTablaMenorMayor(mayorMenor, sumas);
    }//GEN-LAST:event_btn_masMenosActionPerformed

    public void refrescarTablaMenorMayor(int[] mayorMenor, Map<Integer, Double> sumas) {
        //Borra los elementos del modelo
        while (modeloNuevo.getRowCount() > 0) {
            modeloNuevo.removeRow(0);
        }

        //Agregar la fila del bus con mayor ganancia
        Object[] filaMayor = {mayorMenor[0], sumas.get(mayorMenor[0])};
        modeloNuevo.addRow(filaMayor);

        //Agregar la fila del bus con menor ganancia
        Object[] filaMenor = {mayorMenor[1], sumas.get(mayorMenor[1])};
        modeloNuevo.addRow(filaMenor);

        jt_Matriz.setModel(modeloNuevo);
    }

    private void btn_porcentajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_porcentajeActionPerformed
        double[][] buses = matriz.getBuses();
        aumento.aplicarAumento(buses);

        double[] aumentoPorcentaje = aumento.getAumentoPorcentaje();

        refrescarTablaAumento(buses, aumentoPorcentaje);

    }//GEN-LAST:event_btn_porcentajeActionPerformed

    public void refrescarTablaAumento(double[][] buses, double[] aumentoPorcentaje) {
        //Borra los elementos del modelo
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        double[] promedio = aumento.getPromedio();
        //Agrega las filas de la matriz a la JTable
        for (int i = 0; i < buses.length; i++) {
            Object[] fila = new Object[buses[i].length];
            fila[0] = buses[i][0]; //Numero del bus
            for (int j = 1; j < buses[i].length; j++) {
                if (buses[i][j] < promedio[i]) {
                    double aumento = buses[i][j] * 0.20;
                    fila[j] = buses[i][j] + aumento; //Aumenta el 20%
                } else {
                    fila[j] = buses[i][j];//Valores de dias sin aumento
                }
            }
            modelo.addRow(fila);
        }

        jt_Matriz.setModel(modelo);
    }

    private void btn_masActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_masActionPerformed

        double[][] buses = matriz.getBuses();
        dia.MostrarMayor(buses);

        double[] Mayor = dia.getMayor();

        refrescarTablaMayor(buses, Mayor);
    }//GEN-LAST:event_btn_masActionPerformed
    public void refrescarTablaMayor(double[][] buses, double[] Mayor) {
        //Borra los elementos del modelo
        while (modeloNuevo.getRowCount() > 0) {
            modeloNuevo.removeRow(0);
        }

        //Agregar el dia que mas gana de la matriz a la JTable
        for (int i = 0; i < buses.length; i++) {
            Object[] fila = new Object[2];
            fila[0] = buses[i][0]; //Numero del bus
            fila[1] = Mayor[i];//Dia que mas gana
            modeloNuevo.addRow(fila);
        }
        jt_Matriz.setModel(modeloNuevo);
    }
    private void btn_matrizOriginalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_matrizOriginalActionPerformed
        double[][] buses = matriz.getBuses();
        refrescarMatrizBase(buses);
    }//GEN-LAST:event_btn_matrizOriginalActionPerformed

    public void refrescarMatrizBase(double[][] datosMatriz) {

        //Borra los elementos del modelo
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }

        for (int i = 0; i < datosMatriz.length; i++) {
            Double[] fila = new Double[datosMatriz[i].length];
            for (int j = 0; j < datosMatriz[i].length; j++) {
                fila[j] = datosMatriz[i][j];
            }
            modelo.addRow(fila);
        }

        jt_Matriz.setModel(modelo);

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Registro;
    private javax.swing.JButton btn_mas;
    private javax.swing.JButton btn_masMenos;
    private javax.swing.JButton btn_matrizOriginal;
    private javax.swing.JButton btn_porcentaje;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jt_Matriz;
    // End of variables declaration//GEN-END:variables

    class FondoPanel extends JPanel {

        private Image imagen;

        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);

            super.paint(g);
        }
    }
}
