package Logica;

import GUI.Inicio;

public class BusesGUI {

    public static void main(String[] args) {
  // Se crea instancia de la clase GUI Inicio
        Inicio inicio = new Inicio();

        // Llama al JFrame
        inicio.setVisible(true);
        
    }
}
