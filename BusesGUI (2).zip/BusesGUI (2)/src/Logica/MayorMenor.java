package Logica;

import java.util.HashMap;
import java.util.Map;

public class MayorMenor extends LlenarMatriz {

    public Map<Integer, Double> calcularSumaTotal(double[][] buses) {
        Map<Integer, Double> sumas = new HashMap<>();

        for (int i = 0; i < buses.length; i++) {
            double suma = 0;
            for (int j = 1; j < buses[i].length; j++) {
                suma += buses[i][j];
            }
            sumas.put((int) buses[i][0], suma);
        }
        return sumas;
    }

    public int[] encontrarMayorMenor(Map<Integer, Double> sumas) {
        double mayorGanancia = Double.MIN_VALUE;
        double menorGanancia = Double.MAX_VALUE;
        int busMayor = 0;
        int busMenor = 0;
        
        for(Map.Entry<Integer, Double> entry : sumas.entrySet()){
            int numBus = entry.getKey();
            double total = entry.getValue();
            
            if (total > mayorGanancia){
                mayorGanancia = total;
                busMayor = numBus;
            } else {
                menorGanancia = total;
                busMenor = numBus;
            }
        }
        return new int[]{busMayor, busMenor};
    }
}
