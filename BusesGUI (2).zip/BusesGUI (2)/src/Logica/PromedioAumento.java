package Logica;

public class PromedioAumento extends LlenarMatriz {
    private double[] promedio;
    private double[] aumentoPorcentaje;
    
    public void aplicarAumento(double[][] buses) {
        int semana = buses.length; //Ordenar para que se maneje por el tamano de los dias de la semana
        aumentoPorcentaje = new double[semana];
        promedio = new double[semana];

        for (int i = 0; i < semana; i++) {
            double sumaSemana = 0; // Variable de suma a la semana
            for (int j = 1; j < buses[i].length; j++) {
                sumaSemana += buses[i][j]; // Suma de la semana sumando lo de la matriz
            }
            // Calcular promedio de ventas por cada bus a la semana
            promedio[i] = sumaSemana / buses[i].length;
        }

        for (int i = 0; i < semana; i++) {
            //double promedioSemanal = promedio[i]/(buses[i].length-1);
            aumentoPorcentaje[i] = 0;
            for (int j = 1; j < buses[i].length; j++) {
                if (buses[i][j] < promedio[i]) {
                    // Calcular el aumento basado en el promedio de ventas de la semana
                    double aumento = buses[i][j] * 0.20;
                    // Agregar el aumento al valor existente en aumentoPorcentaje
                    aumentoPorcentaje[i] += aumento;
                } else {
                    // Si las ventas son mayores o iguales al promedio, mantener el mismo valor
                    aumentoPorcentaje[i] = buses[i][j];
                }
            }
        }
    }
 
    public double[] getPromedio() {
        return promedio;
    }

    public double[] getAumentoPorcentaje() {
        return aumentoPorcentaje;
    }
}
