package Logica;

public class DiaMayor extends LlenarMatriz {

    private double[] Mayor;
    private double mayorNum;

    public void MostrarMayor(double[][] buses) {
        int semana = buses.length;
        Mayor = new double[semana];

        for (int i = 0; i < semana; i++) {
            mayorNum = Double.MIN_VALUE; // Se inicializa en cada fila
            for (int j = 1; j < buses[i].length; j++) {
                if (buses[i][j] > mayorNum) {
                    mayorNum = buses[i][j];

                }
            }
            Mayor[i] = mayorNum;//Guarda el mayor de la fila
        }
    }

    public double[] getMayor() {
        return Mayor;
    }
}
