package Logica;

import javax.swing.JOptionPane;

public class LlenarMatriz {

    private int numFilas;
    double buses[][] = new double[0][8];

    public int getNumFilas() {
        return numFilas;
    }

    public void setNumFilas(int numFilas) {
        this.numFilas = numFilas;
    }

    public double[][] getBuses() {
        return buses;
    }

    public double[][] Llenar() {

        //Registar el numero de Buses
        setNumFilas(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad de buses a registrar",
                "Ingresar cantidad buses", 1)));

        this.buses = new double[getNumFilas()][8];

        //Llenar la Matriz completa
        for (int i = 0; i < getNumFilas(); i++) {
            buses[i][0] = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero del bus " + (i + 1),
                    "Numero Bus", 1));
            for (int j = 1; j < buses[i].length; j++) {
                buses[i][j] = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el valor trabajado del bus "
                        + "" + (i + 1) + " para el dia " + j, "Ingresar precio", 1));
            }
        }
        return buses;
    }
}
