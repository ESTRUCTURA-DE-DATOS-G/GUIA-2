
package estacionclimatica;

import java.util.Arrays;
import javax.swing.JOptionPane;


public class Temperaturas {

    private float tempMaxima[][];
    private float tempMinima[][];
    private int paresTemp;
    private String dias[];
    private String matrizGeneral[][];
    private String calcularTempMaxima[];
    private String calcularTempMinima[];
    private String calcularDia[];
    private float mediaMax;
    private float mediaMin;

    public Temperaturas(float[][] tempMaxima, float[][] tempMinima, int paresTemp, String[] dias, String[][] matrizGeneral, String[] calcularTempMaxima, String[] calcularTempMinima, String[] calcularDia, float mediaMax, float mediaMin) {
        this.tempMaxima = tempMaxima;
        this.tempMinima = tempMinima;
        this.paresTemp = paresTemp;
        this.dias = dias;
        this.matrizGeneral = matrizGeneral;
        this.calcularTempMaxima = calcularTempMaxima;
        this.calcularTempMinima = calcularTempMinima;
        this.calcularDia = calcularDia;
        this.mediaMax = mediaMax;
        this.mediaMin = mediaMin;
    }

    public float getMediaMax() {
        return mediaMax;
    }

    public void setMediaMax(float mediaMax) {
        this.mediaMax = mediaMax;
    }

    public float getMediaMin() {
        return mediaMin;
    }

    public void setMediaMin(float mediaMin) {
        this.mediaMin = mediaMin;
    }

    public Temperaturas() {

    }

    public String[] getCalcularTempMaxima() {
        return calcularTempMaxima;
    }

    public void setCalcularTempMaxima(String[] calcularTempMaxima) {
        this.calcularTempMaxima = calcularTempMaxima;
    }

    public String[] getCalcularTempMinima() {
        return calcularTempMinima;
    }

    public void setCalcularTempMinima(String[] calcularTempMinima) {
        this.calcularTempMinima = calcularTempMinima;
    }

    public String[] getCalcularDia() {
        return calcularDia;
    }

    public void setCalcularDia(String[] calcularDia) {
        this.calcularDia = calcularDia;
    }

    public String[][] getMatrizGeneral() {
        return matrizGeneral;
    }

    public void setMatrizGeneral(String[][] matrizGeneral) {
        this.matrizGeneral = matrizGeneral;
    }

    public String[] getDias() {
        return dias;
    }

    public void setDias(String[] dias) {
        this.dias = dias;
    }

    public float[][] getTempMaxima() {
        return tempMaxima;
    }

    public void setTempMaxima(float[][] tempMaxima) {
        this.tempMaxima = tempMaxima;
    }

    public float[][] getTempMinima() {
        return tempMinima;
    }

    public void setTempMinima(float[][] tempMinima) {
        this.tempMinima = tempMinima;
    }

    public int getParesTemp() {
        return paresTemp;
    }

    public void setParesTemp(int paresTemp) {
        this.paresTemp = paresTemp;
    }

    public void llenarMatriz() {
        setParesTemp(Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuantos pares de temperaturas diarias desea ingresar?",
                "Pares de Temperaturas", 1)));

        dias = new String[]{"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};

        tempMinima = new float[getParesTemp()][7];
        tempMaxima = new float[getParesTemp()][7];

        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {

                do {
                    if (tempMinima[i][j] < -40 || tempMinima[i][j] > 40) {
                        JOptionPane.showMessageDialog(null, "Ingresar solo valores entre -40° y 40°",
                                "ERROR", 0);
                    }

                    tempMinima[i][j] = Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese la temperatura minima del"
                            + " dia " + dias[j] + ", para el par " + (i + 1), "Temperaturas Minimas", 1));

                } while (tempMinima[i][j] < -40 || tempMinima[i][j] > 40);

            }
        }

        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {

                do {
                    if (tempMaxima[i][j] < -40 || tempMaxima[i][j] > 40) {
                        JOptionPane.showMessageDialog(null, "Ingresar solo valores entre -40° y 40°",
                                "ERROR", 0);
                    }

                    tempMaxima[i][j] = Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese la temperatura maxima para"
                            + " el dia " + dias[j] + ", par " + (i + 1), "Temperaturas Maximas", 1));

                } while (tempMaxima[i][j] < -40 || tempMaxima[i][j] > 40);

            }
        }

    }

    public void matrizGeneral() {

        matrizGeneral = new String[getParesTemp()][7];

        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {
                matrizGeneral[i][j] = ("Min: " + Float.toString(tempMinima[i][j])) + "°" + " / " + ("Max: " + Float.toString(tempMaxima[i][j])) + "°";
            }
        }

    }

//Metodo para calcular dia y temperatura, cuyas temperaturas máximas estén entre 15 y 20 grados
    public void calcularTemperaturasMaximas() {
        calcularTempMaxima = new String[getParesTemp() * 7];
        int index = 0;
        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {
                if (tempMaxima[i][j] >= 15.0 && tempMaxima[i][j] <= 20) {
                    calcularTempMaxima[index] = dias[j] + ": " + Float.toString(tempMaxima[i][j]) + "°";

                } else {
                    calcularTempMaxima[index] = dias[j] + ": --";

                }

               if (dias[j] == "Domingo") {
                        calcularTempMaxima[index] += "\n";
                        calcularTempMaxima[index] += "PAR " +(i+1)+ "^";
                        calcularTempMaxima[index] += "\n";
                        
                    }

                index++;
            }

        }

        setCalcularTempMaxima(calcularTempMaxima);

    }

    public void calcularTemperaturasMinimas() {
        calcularTempMinima = new String[getParesTemp() * 7];
        int index = 0;
        for (int i = 0; i < getParesTemp(); i++) {

            for (int j = 0; j < 7; j++) {

                if (tempMinima[i][j] <= 0) {
                    calcularTempMinima[index] = dias[j] + ": " + Float.toString(tempMinima[i][j]) + "°";

                } else {
                    calcularTempMinima[index] = dias[j] + ": --";
                }

                
                    if (dias[j] == "Domingo") {
                        calcularTempMinima[index] += "\n";
                        calcularTempMinima[index] += "PAR " + (i+1)+ "^";
                        calcularTempMinima[index] += "\n";
                        
                    }

                

                index++;
            }

        }

        setCalcularTempMinima(calcularTempMinima);

    }

    public void calcularMediaMaxima() {
        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {
                mediaMax += (Math.abs(tempMaxima[i][j]) / (getParesTemp() * 7));
            }
        }

        setMediaMax(mediaMax);
    }

    public void calcularMediaMinima() {
        for (int i = 0; i < getParesTemp(); i++) {
            for (int j = 0; j < 7; j++) {
                mediaMin += (Math.abs(tempMinima[i][j]) / (getParesTemp() * 7));
            }
        }

        setMediaMin(mediaMin);
    }

}
